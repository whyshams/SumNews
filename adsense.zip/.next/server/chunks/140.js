"use strict";
exports.id = 140;
exports.ids = [140];
exports.modules = {

/***/ 3140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ResultContextProvider),
/* harmony export */   "useResultContext": () => (/* binding */ useResultContext)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);



const ResultContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
function ResultContextProvider({ children  }) {
    const { 0: bdNewsData , 1: setBdNewsData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: bdNewsDataDiv , 1: setBdNewsDataDiv  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: bdNewsDataCat , 1: setBdNewsDataCat  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: catData , 1: setCatData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const { 0: sumData , 1: setSumData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: sumInput , 1: setSumInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: sumText , 1: setSumText  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const { 0: sumError , 1: setSumError  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: Loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: copied , 1: setCopied  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const getData = async ()=>{
            setLoading(true);
            await axios__WEBPACK_IMPORTED_MODULE_2___default().request({
                method: "POST",
                url: "https://tldrthis.p.rapidapi.com/v1/model/abstractive/summarize-url/",
                headers: {
                    "content-type": "application/json",
                    "X-RapidAPI-Key": "fffe31e05amsh9923ff790f0b752p11d51ajsn80d6db57d239",
                    "X-RapidAPI-Host": "tldrthis.p.rapidapi.com"
                },
                data: `{"url":"${sumInput}","min_length":100,"max_length":300,"is_detailed":true}`
            }).then((response)=>setSumData(response.data)).catch((err)=>setSumError(true)).finally(()=>setLoading(false));
        };
        if (sumInput !== "") {
            getData();
        }
    }, [
        sumInput
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ResultContext.Provider, {
        value: {
            Loading,
            setLoading,
            sumError,
            bdNewsData,
            setBdNewsData,
            bdNewsDataDiv,
            setBdNewsDataDiv,
            catData,
            setCatData,
            sumData,
            setSumData,
            sumInput,
            setSumInput,
            sumText,
            setSumText,
            copied,
            setCopied,
            bdNewsDataCat,
            setBdNewsDataCat
        },
        children: children
    });
};
const useResultContext = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(ResultContext);


/***/ })

};
;