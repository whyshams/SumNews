(() => {
var exports = {};
exports.id = 888;
exports.ids = [888,356];
exports.modules = {

/***/ 2640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./pages/Contexts/ResultContextProvider.js
var ResultContextProvider = __webpack_require__(3140);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
var router_default = /*#__PURE__*/__webpack_require__.n(router_);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons"
var external_react_icons_ = __webpack_require__(6698);
;// CONCATENATED MODULE: external "react-icons/tb"
const tb_namespaceObject = require("react-icons/tb");
;// CONCATENATED MODULE: ./Components/NavBar.js







const NavBar = ()=>{
    const { 0: bdOpen , 1: setBdOpen  } = (0,external_react_.useState)(false);
    const { 0: bdNatOpen , 1: setBdNatOpen  } = (0,external_react_.useState)(false);
    const { 0: homeOpen , 1: setHomeOpen  } = (0,external_react_.useState)(false);
    const router = (0,router_.useRouter)();
    console.log(router.query);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "menu d-block ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onClick: ()=>setHomeOpen(true),
                        className: homeOpen ? "nav-button-active " : "nav-button ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "fontType",
                            children: "sum(NEWS)"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "Nav ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/TopNews/World",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: router.query.Category ? "nav-button-active " : "nav-button ",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "d-flex d-md-none justify-content-center align-items-center",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_icons_.IconContext.Provider, {
                                                value: {
                                                    className: "menuIcon "
                                                },
                                                children: [
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaGlobeAsia, {})
                                                ]
                                            }),
                                            " "
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "d-md-flex d-none",
                                        children: " World News"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            onClick: ()=>setBdOpen(!bdOpen),
                            className: bdOpen ? "nav-button-active" : "nav-button",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "d-flex d-md-none",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_icons_.IconContext.Provider, {
                                            value: {
                                                className: "menuIcon text-success"
                                            },
                                            children: [
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx(tb_namespaceObject.TbLetterB, {})
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_icons_.IconContext.Provider, {
                                            value: {
                                                className: "menuIcon text-danger"
                                            },
                                            children: [
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx(tb_namespaceObject.TbLetterD, {})
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "d-md-block d-none",
                                    children: "Bangladesh"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_icons_.IconContext.Provider, {
                                        value: {
                                            className: " fa-bounce mt-2  d-flex justify-content-center align-items-center navIcon"
                                        },
                                        children: [
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleDown, {})
                                        ]
                                    })
                                }),
                                " "
                            ]
                        }),
                        bdOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "submenu",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/BDnews/International",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: router.asPath == "/BDnews/International" ? "nav-button-active" : "nav-button intMedia",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "International Media"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    onClick: ()=>setBdNatOpen(!bdNatOpen),
                                    className: bdNatOpen ? "nav-button-active" : "nav-button",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "Local Media(en)"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_icons_.IconContext.Provider, {
                                            value: {
                                                className: "fa-bounce mt-2 navIconNat"
                                            },
                                            children: [
                                                " ",
                                                /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaAngleDown, {})
                                            ]
                                        })
                                    ]
                                }),
                                bdNatOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "submenu2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/BDnews/Divisional/Dhaka",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: router.query.National ? "nav-button-active" : "nav-button",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Divisional"
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/BDnews/Categorical/news",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: router.query.CategoryBd ? "nav-button-active" : "nav-button",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                    children: "Categorical"
                                                })
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "/BanglaNews/ঢাকা",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: router.query.Division ? "nav-button-active" : "nav-button",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "বাংলা"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/Summarize",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: router.asPath == "/Summarize" ? "nav-button-active" : "nav-button",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: "Summarizer"
                                    })
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Components_NavBar = (NavBar);

;// CONCATENATED MODULE: ./Components/Loading.js


const Loading = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-9 col-md-10 loading d-flex justify-content-center align-items-center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "multi-ripple",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {})
            ]
        })
    });
};
/* harmony default export */ const Components_Loading = (Loading);

;// CONCATENATED MODULE: ./Components/Footer.js



const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "Footer",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "Footer-menu pt-4 pb-1 d-flex flex-wrap justify-content-center align-items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/AboutUs",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "btn text-secondary Footer-button",
                                children: "About Us"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/Terms",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "btn text-secondary Footer-button",
                                children: "Terms & Conditions"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/PrivacyPolicy",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "btn text-secondary Footer-button",
                                children: "Privacy Policy"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "Footer-content",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "copyright mt-3 d-flex justify-content-center align-items-center",
                            children: "\xa9 Databases of Various News API from open source"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "footer-logo",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "mt-5 d-flex text-muted justify-content-center align-items-center",
                                    children: "Brought To You By"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                    className: "fontType mt-2 pb-5 d-flex flex-wrap justify-content-center align-items-center",
                                    children: "sum(NEWS)"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Components_Footer = (Footer);

;// CONCATENATED MODULE: external "nprogress"
const external_nprogress_namespaceObject = require("nprogress");
var external_nprogress_default = /*#__PURE__*/__webpack_require__.n(external_nprogress_namespaceObject);
;// CONCATENATED MODULE: ./Components/Layout.js









(router_default()).onRouteChangeStart = (url)=>{
    external_nprogress_default().start();
    external_nprogress_default().set(0.3);
};
(router_default()).onRouteChangeComplete = ()=>{
    external_nprogress_default().done();
    external_nprogress_default().set(1);
};
const Layout = ({ children  })=>{
    const router = (0,router_.useRouter)();
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(false);
    (0,external_react_.useEffect)(()=>{
        const handleComplete = ()=>{
            setLoading(false);
        };
        const handleStart = ()=>{
            setLoading(true);
        };
        router_default().events.on("routeChangeComplete", handleComplete);
        router_default().events.on("routeChangeStart", handleStart);
        return ()=>{
            router_default().events.off("routeChangeComplete", handleComplete);
            router_default().events.off("routeChangeStart", handleStart);
        };
    }, [
        (router_default())
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("script", {
                    async: true,
                    src: "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5159189580385319",
                    crossOrigin: "anonymous"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row d-flex col-md-12 col-12",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-3 col-md-2 ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Components_NavBar, {})
                    }),
                    loading ? /*#__PURE__*/ jsx_runtime_.jsx(Components_Loading, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-9 col-md-10",
                        children: [
                            " ",
                            children,
                            " "
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("footer", {
                className: "col-md-12 col-12",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Components_Footer, {})
            })
        ]
    });
};
/* harmony default export */ const Components_Layout = (Layout);

// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: ./pages/_app.js





function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(Components_Layout, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ResultContextProvider["default"], {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                    strategy: "afterInteractive",
                    src: "https://www.googletagmanager.com/gtag/js?id=UA-172039083-4"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((script_default()), {
                    strategy: "afterInteractive",
                    id: "google-analytics",
                    children: `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js',new Date());
        gtag('config','UA-172039083-4')
        `
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h1", {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            ]
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(699)


/***/ }),

/***/ 2167:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6698:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [952,273,664,140], () => (__webpack_exec__(2640)));
module.exports = __webpack_exports__;

})();