import React from 'react'

const Loading = () => {
  return (
    <div className='col-9 col-md-10  loading  d-flex justify-content-center align-items-center'>
    <div className="multi-ripple">
    <div></div>
    <div></div>
  </div>
  </div>
  )
}

export default Loading